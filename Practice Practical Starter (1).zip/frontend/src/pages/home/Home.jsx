import { Flex, Heading } from '@chakra-ui/react'
import React from 'react'

export const Home = () => {
  return (
    <Flex justifyContent={'center'}>
      <Heading>This is the homepage for the practice practical assessment</Heading>
    </Flex>
  )
}
